# Lets Go Gambling! - RoR2 SFX Mod.

## What does this do?
Plays the AW YEAH YEAH sfx or aw dang it sfx when you succeed or fail a shrine.
Also plays "I can't stop winning!" when getting a successive win.
Plays "Let's go gambling!" when pinging a Shrine of Chance.

Fully Networked, should play for others when you hit the shrine of chance.

If there are any bugs, let me know in the RoR2 modding discord, or directly at `ethanol10`.

## Latest Release:
- v1.2.1:
    - Added restrictions to when the ping SFX can play. 
        - Added another option to re-enable this play on ping regardless if the shrine has been expended.

## Credits:

- Assets (Icon, SFX):
    - raxdflipnote (Go watch his gamblecore video here: https://www.youtube.com/watch?v=IPFiKEm-oNI)
- Commissioner:
    - fransam
- Programming:
    - ethanol10